<div class="top_nav_main_div d-none d-xxl-block d-xl-block d-lg-block">
    <div class="row">
        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-8 col-sm-12 col-12">
            <div class="top_nav_main_div_left">
                <a href="mailto: shivindservices@outlook.com"><i class="far fa-envelope"></i>
                    <span>shivindservices@outlook.com</span></a>
                <p><i class="far fa-clock"></i> <span>open hours: mon - sat 9:00 <span>am</span> - 7:00 <span>
                            pm</span> </span></p>
            </div>
        </div>
        <div class="col-xxl-6 col-xl-6 col-lg-6 col-md-4 col-sm-12 col-12">
            <div class="top_nav_main_div_right">
                <a href="tel:+91 8980022288"><i class="fas fa-phone"></i> <span>+91 8980022288</span></a>
                <div class="top_nav_main_div_right_inner">
                    <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></span></a>
                    <a href="https://twitter.com/shivindservices?s=11&t=uNRb2yrSOtFFMjanQt9bLA" target="_blank"><i
                            class="fab fa-twitter"></i></span></a>
                    <a href="https://www.instagram.com/shivindservices/?igshid=NTc4MTIwNjQ2YQ%3D%3D" target="_blank"><i
                            class="fab fa-instagram"></i></span></a>
                </div>
            </div>
        </div>
    </div>
</div>